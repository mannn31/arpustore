<!-- ASIDE -->
<div id="aside" class="col-md-3">

	<div class="aside">
		<ul>
			<li style="margin-bottom: 10px"><a class="main-btn btn-block" href="customer.php"> <i class="fa fa-home"></i> &nbsp; Dashboard</a></li>
			<li style="margin-bottom: 10px"><a class="main-btn btn-block" href="customer_pesanan.php"> <i class="fa fa-list"></i> &nbsp; Pesanan Saya</a></li>
			<li style="margin-bottom: 10px"><a class="main-btn btn-block" href="customer_password.php"> <i class="fa fa-lock"></i> &nbsp; Ganti Password</a></li>
			<li style="margin-bottom: 10px"><a class="main-btn btn-block" href="customer_logout.php"> <i class="fa fa-sign-out"></i> &nbsp; Keluar</a></li>
		</ul>
	</div>
</div>
<!-- /ASIDE -->
